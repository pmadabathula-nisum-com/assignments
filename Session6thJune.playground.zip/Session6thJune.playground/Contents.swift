//: Playground - noun: a place where people can play

import UIKit

var str = "Praveen"

@available(iOS 10.0, macOS 10.12, *)

class Item  {
    var binClass : Bin?
    var itemName: String?
}

class Bin  {
    var locationClass : Location?
    var binName : String?
}

class Location  {
    var locationName: String?
}

var itemClass : Item?
itemClass = Item()
itemClass?.itemName = "Print Option Value"

