//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

//Referance type
class someClass {
    var name: String
    init(name: String) {
        self.name = name
    }
}

func jediGreet(name: String, ability: String) -> (farewell: String, mayTheForceBeWithYou: String) {
    return ("Good bye, \(name).", " May the \(ability) be with you.")
}

var aClass = someClass(name: "James")
var bClass = aClass
bClass.name = "Sasha"

print(aClass.name) // "Sasha"
print(bClass.name) // "Sasha"

let retValue = jediGreet(name: "old friend", ability: "Force")


print(retValue) // "Sasha"
print(retValue)
print(retValue.farewell)
print(retValue.mayTheForceBeWithYou)

//Value type.

struct SomeStruct {
    var name: String
    init(name: String) {
        self.name = name
    }
  
}

var aStruct = SomeStruct(name: "James")
var bStruct = aStruct
bStruct.name = "Sasha"

print(aStruct.name) // "James"
print(bStruct.name) // "Sasha"


